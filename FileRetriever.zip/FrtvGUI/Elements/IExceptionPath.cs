﻿namespace FrtvGUI.Elements
{
    public interface IExceptionPath
    {
        string Path { get; }
    }
}
